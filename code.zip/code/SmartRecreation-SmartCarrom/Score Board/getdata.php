<?php
error_reporting(0);
$url="http://idiaal-platform-non-bics.cfapps.io/rest/v1/tenant/smartrecreation/entity/smartcarom/device/camera/data?limit=100&order=DESC";
$strJsonFileContents = file_get_contents($url);
// Convert to array 
$coin = json_decode($strJsonFileContents, true);

//var_dump($coin['records'][1]['data']);
//current data stored in cloud
//............................................................

//red coin position
$xred=$coin['records'][0]['data']['red']['y'];
$PocketedBy=$coin['records'][0]['data']['red']['PocketedBy'];
$yred=$coin['records'][0]['data']['red']['x'];
//$PocketedBy="human";
//$PocketedBy="roboarm";
//..............................................................

//number of coin present on board
$lw= sizeof($coin['records'][0]['data']['white']);
$lb=sizeof($coin['records'][0]['data']['black']);
/*if($PocketedBy!='none'&&$PocketedBy=="human")
{
    $lw=$lw+5;
}

if($PocketedBy!='none'&&$PocketedBy=="roboarm")
{
    $lb=$lb+5;
}
*/



//echo ($lw." </br> ".$lb );



//...........................................................


//striker position
$xstrik=$coin['records'][0]['data']['striker']['y'];
$ystrik=$coin['records'][0]['data']['Striker']['x'];
//echo ($xstrik." </br> ".$ystrik );

//...............................................................

//white coins
//1
$xw0=$coin['records'][0]['data']['white'][0]['y'];
$yw0=$coin['records'][0]['data']['white'][0]['x'];
//2
$xw1=$coin['records'][0]['data']['white'][1]['y'];
$yw1=$coin['records'][0]['data']['white'][1]['x'];
//3
$xw2=$coin['records'][0]['data']['white'][2]['y'];
$yw2=$coin['records'][0]['data']['white'][2]['x'];
//4
$xw3=$coin['records'][0]['data']['white'][3]['y'];
$yw3=$coin['records'][0]['data']['white'][3]['x'];
//5
$xw4=$coin['records'][0]['data']['white'][4]['y'];
$yw4=$coin['records'][0]['data']['white'][4]['x'];
//6
$xw5=$coin['records'][0]['data']['white'][5]['y'];
$yw5=$coin['records'][0]['data']['white'][5]['x'];
//7
$xw6=$coin['records'][0]['data']['white'][6]['y'];
$yw6=$coin['records'][0]['data']['white'][6]['x'];
//8
$xw7=$coin['records'][0]['data']['white'][7]['y'];
$yw7=$coin['records'][0]['data']['white'][7]['x'];
//9
$xw8=$coin['records'][0]['data']['white'][8]['y'];
$yw8=$coin['records'][0]['data']['white'][8]['x'];

//.................................................................

//black coins

$xb0=$coin['records'][0]['data']['black'][0]['y']; 
$yb0=$coin['records'][0]['data']['black'][0]['x'];
//2
$xb1=$coin['records'][0]['data']['black'][1]['y'];
$yb1=$coin['records'][0]['data']['black'][1]['x'];
//3
$xb2=$coin['records'][0]['data']['black'][2]['y'];
$yb2=$coin['records'][0]['data']['black'][2]['x'];
//4
$xb3=$coin['records'][0]['data']['black'][3]['y'];
$yb3=$coin['records'][0]['data']['black'][3]['x'];
//5
$xb4=$coin['records'][0]['data']['black'][4]['y'];
$yb4=$coin['records'][0]['data']['black'][4]['x'];
//6
$xb5=$coin['records'][0]['data']['black'][5]['y'];
$yb5=$coin['records'][0]['data']['black'][5]['x'];
//7
$xb6=$coin['records'][0]['data']['black'][6]['y'];
$yb6=$coin['records'][0]['data']['black'][6]['x'];
//8
$xb7=$coin['records'][0]['data']['black'][7]['y'];
$yb7=$coin['records'][0]['data']['black'][7]['x'];
//9
$xb8=$coin['records'][0]['data']['black'][8]['y'];
$yb8=$coin['records'][0]['data']['black'][8]['x'];
//$xb9=$coin['records'][0]['data']['black'][9]['x'];
//if($xb9==null)
//{
 //   print("hello");
//}
//..................................................................

?>