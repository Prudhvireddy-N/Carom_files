<?php
include 'getdata.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Score Board</title>
    <link rel="stylesheet" href="css/newboardstyle.css">
</head>
<body>
    <header>
        <h1>MATCH SCORE<h1>
    </header>
    <aside class="rightside">HUMAN</aside>
    <aside class="leftside">ROBOT</aside>
    <article></article>
    <a href="stream.php" class="stream">game stream</a>
    <div id="MyClockDisplay" class="clock" onload="showTime()"></div><br><br>
    <p id="date" class="todaydate"></p>
	<?php
//black points

$pointb=(9-$lb)*10;
//white points
$pointw=(9-$lw)*10;

//if($pointb>=90)
//{
	//header("Location:fireworkrobot.html");
//}
//if($pointw>=90)
//{
	//header("Location:fireworkhuman.html");
//}

?>
    <div class="humanpoints"><h3><?php echo($pointb);?></h3></div>
    <div class="robopoints"><h3><?php echo($pointw);?><h3></div>
    
</body>
<script>


function stream()
{
	navigator.mediaDevices.getUserMedia({
		audio:true,
		video:true
	}).then(stream=>{
		document.getElementById("video").srcObject=stream;
	})
}

n =  new Date();
y = n.getFullYear();
m = n.getMonth() + 1;
d = n.getDate();
document.getElementById("date").innerHTML = m + "/" + d + "/" + y;



    function showTime(){
    var date = new Date();
    var h = date.getHours(); // 0 - 23
    var m = date.getMinutes(); // 0 - 59
    var s = date.getSeconds(); // 0 - 59
    var session = "AM";
    
    if(h == 0){
        h = 12;
    }
    
    if(h > 12){
        h = h - 12;
        session = "PM";
    }
    
    h = (h < 10) ? "0" + h : h;
    m = (m < 10) ? "0" + m : m;
    s = (s < 10) ? "0" + s : s;
    
    var time = h + ":" + m + ":" + s + " " + session;
    document.getElementById("MyClockDisplay").innerText = time;
    document.getElementById("MyClockDisplay").textContent = time;
    
    setTimeout(showTime, 1000);
    
}

showTime();
    </script>
</html>