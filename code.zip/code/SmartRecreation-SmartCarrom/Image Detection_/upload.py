import threading
import requests
import json

def test():
    #threading.Timer(2.0,test).start()
    f = open("data.txt", "r")
    s=f.read()
    #print(s)
    data = {}
    #data['coin'] = []
    s=s.split(' ')
    print(s)
    for i in range(0,len(s)-3,3):
            print(s[i],s[i+1],s[i+2])
            if s[i] not in data:
                data[s[i]]=[]
                data[s[i]].append({
        'x' : float(s[i+1]),
        'y' : float(s[i+2])
                })
            else :
                data[s[i]].append({
        'x' : float(s[i+1]),
        'y' : float(s[i+2])
                })
    print('\n')
    
    if 'black' not in data:
        data['black'] = []
    if 'striker' not in data:
        data['striker'] = []
    if 'white' not in data:
        data['white'] = []
    if 'red' not in data:
        data['red'] = []
    if 'tape' not in data:
        data['tape'] = []
    if 'angle' not in data and len(data['tape'])!=0:
        data['angle'] = []
        data['angle'].append(data['tape'][0])
        data['angle'].append(data['striker'][0])
    print(data)   
    json_data=json.dumps(data)
    print(json_data)
    with open('data.json', 'w') as outfile:  
        json.dump(data, outfile)
    url = 'https://idiaal-platform-non-bics.cfapps.io/rest/v1/tenant/smartrecreation/entity/smartcarom/device/camera/data'
    headers = {'Content-Type': 'application/json','Accept': 'application/json','api_key': 'apiKey'}
    response = requests.post(url, data=json_data, headers=headers)
    #pprint.pprint(response.json()
test()