import os
while True:
    os.system("python camera.py")
    os.system("./darknet detect yolov3-tiny_objss.cfg yolov3-tiny_objss_105000.weights picture.jpg")
    os.system("python upload.py")